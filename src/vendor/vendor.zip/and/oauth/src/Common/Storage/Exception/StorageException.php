<?php

namespace OAuth\Common\Storage\Exception;

use OAuth\Common\Exception\Exception;

/**
 * Generic storage exception.
 */
class StorageException extends Exception
{
}
